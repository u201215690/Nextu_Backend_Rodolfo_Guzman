var monto_from = 1000;
var monto_to = 20000;
 
$(document).ready(function() {
	
	
	// Habilita los select de la libreria materializecss
    $('select').material_select();
	
	
	//Carga los Selects 
	cargarSelect();
	

});


//Inicializador del elemento Slider
$("#rangoPrecio").ionRangeSlider({
  type: "double",
  grid: false,
  min: 0,
  max: 100000,
  from: 1000,
  to: 20000,
  prefix: "$",
  onChange: function (data) {
	  monto_from = data.from;
	  monto_to = data.to;  
  }
})


function setSearch() {
  let busqueda = $('#checkPersonalizada')
  this.customSearch = true;
  busqueda.on('change', (e) => {
    if (this.customSearch == false) {
      this.customSearch = true
    } else {
      this.customSearch = false
    }
    $('#personalizada').toggleClass('invisible')
  })
}
setSearch()


function buscarPropiedad(){
	
	//Busqueda Total
	if(customSearch == true){
		cargarListaPropiedad(1);
	}else{ //Busqueda Personalizada
		cargarListaPropiedad(2);
	}
	
}

function cargarListaPropiedadXD(modalidad){
	
	var cad = "";
	$.getJSON("data.json", function(data){
			//for para decorre las propiedades  
			for(datos in data.contenido){
				//console.log(data.contenido[datos].Direccion);
				var obj = data.contenido[datos];
				
				if(modalidad == 1 ){
					
					cad += '<div class="card horizontal"><div class="card-image"><img src="img/home.jpg" width = "500"></div>';
					cad += '<div class="card-stacked"><div class="card-content">';
				
						cad += '<div><b>Direccion: </b>'+obj.Direccion+'</div>';
						cad += '<div><b>Ciudad: </b>'+obj.Ciudad+'</div>';
						cad += '<div><b>Telefono: </b>'+obj.Telefono+'</div>';
						cad += '<div><b>Código postal: </b>'+obj.Codigo_Postal+'</div>';
						cad += '<div><b>Precio: </b>'+obj.Precio+'</div>';
						cad += '<div><b>Tipo: </b>'+obj.Tipo+'</div>';
				
					cad += '</div><div class="card-action right-align"><a href="#">Ver más</a></div></div></div>';
					
				}else{

					if(obj.Precio >= monto_from ){
						
						cad += '<div class="card horizontal"><div class="card-image"><img src="img/home.jpg" width = "500"></div>';
						cad += '<div class="card-stacked"><div class="card-content">';
					
							cad += '<div><b>Direccion: </b>'+obj.Direccion+'</div>';
							cad += '<div><b>Ciudad: </b>'+obj.Ciudad+'</div>';
							cad += '<div><b>Telefono: </b>'+obj.Telefono+'</div>';
							cad += '<div><b>Código postal: </b>'+obj.Codigo_Postal+'</div>';
							cad += '<div><b>Precio: </b>'+obj.Precio+'</div>';
							cad += '<div><b>Tipo: </b>'+obj.Tipo+'</div>';
					
						cad += '</div><div class="card-action right-align"><a href="#">Ver más</a></div></div></div>';
					}
				}
				$('#dv_lista').html(cad);
			}
			
	});
}


function cargarListaPropiedad(modalidad){
	
	var cad = "";
	if(modalidad == 1 ){
		$.getJSON("data.json", function(data){
			//for para decorre las propiedades  
			for(datos in data.contenido){
				//console.log(data.contenido[datos].Direccion);
				var obj = data.contenido[datos];
				cad += '<div class="card horizontal"><div class="card-image"><img src="img/home.jpg" width = "500"></div>';
				cad += '<div class="card-stacked"><div class="card-content">';
			
					cad += '<div><b>Direccion: </b>'+obj.Direccion+'</div>';
					cad += '<div><b>Ciudad: </b>'+obj.Ciudad+'</div>';
					cad += '<div><b>Telefono: </b>'+obj.Telefono+'</div>';
					cad += '<div><b>Código postal: </b>'+obj.Codigo_Postal+'</div>';
					cad += '<div><b>Precio: </b>'+obj.Precio+'</div>';
					cad += '<div><b>Tipo: </b>'+obj.Tipo+'</div>';
			
				cad += '</div><div class="card-action right-align"><a href="#">Ver más</a></div></div></div>';
				
			}
			$('#dv_lista').html(cad);	
		});
	}else{
		var ciudad = $('#ciudad').val(); 
		var tipo = $('#tipo').val();
		$.getJSON("data.json", function(data){
			//for para decorre las propiedades  
			for(datos in data.contenido){
				//console.log(data.contenido[datos].Direccion);
				var obj = data.contenido[datos];
				console.log(obj.Ciudad + "  "+ ciudad);
				
				if(ciudad !=0 && tipo == 0 ){
					if((format(obj.Precio) >= monto_from  && format(obj.Precio) <= monto_to) && obj.Ciudad == ciudad ){
						cad += '<div class="card horizontal"><div class="card-image"><img src="img/home.jpg" width = "500"></div>';
						cad += '<div class="card-stacked"><div class="card-content">';
					
							cad += '<div><b>Direccion: </b>'+obj.Direccion+'</div>';
							cad += '<div><b>Ciudad: </b>'+obj.Ciudad+'</div>';
							cad += '<div><b>Telefono: </b>'+obj.Telefono+'</div>';
							cad += '<div><b>Código postal: </b>'+obj.Codigo_Postal+'</div>';
							cad += '<div><b>Precio: </b>'+obj.Precio+'</div>';
							cad += '<div><b>Tipo: </b>'+obj.Tipo+'</div>';
					
						cad += '</div><div class="card-action right-align"><a href="#">Ver más</a></div></div></div>';
					}
				}else if(tipo !=0 && ciudad == 0){
					if((format(obj.Precio) >= monto_from  && format(obj.Precio) <= monto_to) && obj.Tipo == tipo ){
						cad += '<div class="card horizontal"><div class="card-image"><img src="img/home.jpg" width = "500"></div>';
						cad += '<div class="card-stacked"><div class="card-content">';
					
							cad += '<div><b>Direccion: </b>'+obj.Direccion+'</div>';
							cad += '<div><b>Ciudad: </b>'+obj.Ciudad+'</div>';
							cad += '<div><b>Telefono: </b>'+obj.Telefono+'</div>';
							cad += '<div><b>Código postal: </b>'+obj.Codigo_Postal+'</div>';
							cad += '<div><b>Precio: </b>'+obj.Precio+'</div>';
							cad += '<div><b>Tipo: </b>'+obj.Tipo+'</div>';
					
						cad += '</div><div class="card-action right-align"><a href="#">Ver más</a></div></div></div>';
					}
				}else if(tipo !=0 && ciudad != 0){
					if((format(obj.Precio) >= monto_from  && format(obj.Precio) <= monto_to) && obj.Tipo == tipo && obj.Ciudad == ciudad ){
						cad += '<div class="card horizontal"><div class="card-image"><img src="img/home.jpg" width = "500"></div>';
						cad += '<div class="card-stacked"><div class="card-content">';
					
							cad += '<div><b>Direccion: </b>'+obj.Direccion+'</div>';
							cad += '<div><b>Ciudad: </b>'+obj.Ciudad+'</div>';
							cad += '<div><b>Telefono: </b>'+obj.Telefono+'</div>';
							cad += '<div><b>Código postal: </b>'+obj.Codigo_Postal+'</div>';
							cad += '<div><b>Precio: </b>'+obj.Precio+'</div>';
							cad += '<div><b>Tipo: </b>'+obj.Tipo+'</div>';
					
						cad += '</div><div class="card-action right-align"><a href="#">Ver más</a></div></div></div>';
					}
				
				}else if(tipo ==0 && ciudad == 0){
					if(format(obj.Precio) >= monto_from  && format(obj.Precio) <= monto_to){
						cad += '<div class="card horizontal"><div class="card-image"><img src="img/home.jpg" width = "500"></div>';
						cad += '<div class="card-stacked"><div class="card-content">';
					
							cad += '<div><b>Direccion: </b>'+obj.Direccion+'</div>';
							cad += '<div><b>Ciudad: </b>'+obj.Ciudad+'</div>';
							cad += '<div><b>Telefono: </b>'+obj.Telefono+'</div>';
							cad += '<div><b>Código postal: </b>'+obj.Codigo_Postal+'</div>';
							cad += '<div><b>Precio: </b>'+obj.Precio+'</div>';
							cad += '<div><b>Tipo: </b>'+obj.Tipo+'</div>';
					
						cad += '</div><div class="card-action right-align"><a href="#">Ver más</a></div></div></div>';
					}
				}
				
				
			}
			$('#dv_lista').html(cad);	
		});
	}
}

function format(str)
{
	var newstr = str.replace(/[$,]/gi,'');
	return newstr*1;
}



function cargarSelect(){
	
	$.getJSON("data.json", function(data){
		
		//for para decorre las propiedades  
		var selectCiudad = '<option value="0" >Escoge una ciudad</option>';
		var selectTipo = '<option value="0" >Escoge Tipo</option>';
		
		for(datos in data.contenido){
			var obj = data.contenido[datos];      
			
			selectCiudad += '<option value="'+obj.Ciudad+'" >'+obj.Ciudad+'</option>';
			selectTipo += '<option value="'+obj.Tipo+'" >'+obj.Tipo+'</option>';
		}
		//alert(selectCiudad);
		$('#ciudad').html(selectCiudad);
		$("#ciudad").material_select();
		
		$('#tipo').html(selectTipo);
		$("#tipo").material_select();
		
	});
}





